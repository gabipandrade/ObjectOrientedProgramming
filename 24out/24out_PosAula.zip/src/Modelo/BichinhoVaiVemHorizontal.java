package Modelo;

import Auxiliar.Consts;
import Auxiliar.Desenho;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.io.IOException;
import java.io.Serializable;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class BichinhoVaiVemHorizontal extends Personagem  implements Serializable{
    private boolean bRight;
    private int contaFrames;
    public BichinhoVaiVemHorizontal(String sNomeImagePNG) {
        super(sNomeImagePNG);
        bRight = true;
    }
    public void autoDesenho(){
        contaFrames++;
        if(bRight && contaFrames==5){
           this.setPosicao(pPosicao.getLinha(), pPosicao.getColuna()+1);
           contaFrames=0;
        }
        else if(!bRight && contaFrames==5 ){
            this.setPosicao(pPosicao.getLinha(), pPosicao.getColuna()-1);           
            contaFrames=0;
        }
            
        super.autoDesenho();
        bRight = !bRight;
    }
}
