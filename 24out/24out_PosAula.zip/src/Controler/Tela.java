package Controler;

import Modelo.pokeball;
import Modelo.Personagem;
//import Modelo.Caveira;
import Modelo.Hero;
import Modelo.BichinhoVaiVemHorizontal;
import Modelo.Bichinhoteleporta;
import Modelo.Muro;
import Modelo.ZigueZague;
import Modelo.snake;
import Modelo.Tiro;

import auxiliar.Posicao;
import Auxiliar.Consts;
import Auxiliar.Desenho;

//import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;

//import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
import java.io.IOException;
//import java.io.ObjectInputStream;
//import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
//import java.util.zip.GZIPInputStream;
//import java.util.zip.GZIPOutputStream;
//import javax.swing.JButton;

public class Tela extends javax.swing.JFrame implements MouseListener, KeyListener {

    private Hero hero;
    private ArrayList<Personagem> faseAtual;
    private ControleDeJogo cj = new ControleDeJogo();
    private Graphics g2;
    private int iTimer;
    private int Fase;
    public Tela() {
        iTimer = 0;
        Fase=1;
        Desenho.setCenario(this);
        initComponents();
        this.addMouseListener(this);
        /*mouse*/
        this.addKeyListener(this);
        /*teclado*/

 /*Cria a janela do tamanho do tabuleiro + insets (bordas) da janela*/
        this.setSize(Consts.RESy * Consts.CELL_SIDE + getInsets().left + getInsets().right,
                Consts.RESx * Consts.CELL_SIDE + getInsets().top + getInsets().bottom);

        faseAtual = new ArrayList<Personagem>();
        
        
        /*Cria faseAtual adiciona personagens*/
        hero = new Hero("btrainer11.png");
        hero.setPosicao(14, 5);
        this.addPersonagem(hero);

        ZigueZague zz = new ZigueZague("robo.png");
        zz.setPosicao(5, 5);
        this.addPersonagem(zz);

        BichinhoVaiVemHorizontal bBichinhoH = new BichinhoVaiVemHorizontal("roboPink.png");
        bBichinhoH.setPosicao(3, 3);
        this.addPersonagem(bBichinhoH);

        BichinhoVaiVemHorizontal bBichinhoH2 = new BichinhoVaiVemHorizontal("roboPink.png");
        bBichinhoH2.setPosicao(6, 6);
        this.addPersonagem(bBichinhoH2);
        /*
        Caveira bV1 = new Caveira("caveira.png");
        bV1.setPosicao(5, 1);
        this.addPersonagem(bV1);
        
        Caveira bV2 = new Caveira("caveira.png");
        bV2.setPosicao(6, 1);
        this.addPersonagem(bV2);
        
        Caveira bV3 = new Caveira("caveira.png");
        bV3.setPosicao(7, 1);
        this.addPersonagem(bV3);
         */
        pokeball pb1 = new pokeball("pokeballb.png");
        pb1.setPosicao(3, 2);
        this.addPersonagem(pb1);

        pokeball pb2 = new pokeball("pokeball.png");
        pb2.setPosicao(10, 3);
        this.addPersonagem(pb2);

        pokeball pb3 = new pokeball("pokeball.png");
        pb3.setPosicao(3, 12);
        this.addPersonagem(pb3);

        pokeball pb4 = new pokeball("pokeball.png");
        pb4.setPosicao(12, 12);
        this.addPersonagem(pb4);

        snake s1 = new snake("snake.png");
        s1.setPosicao(3, 7);
        this.addPersonagem(s1);

        snake s2 = new snake("snake.png");
        s2.setPosicao(5, 14);
        this.addPersonagem(s2);

        snake s3 = new snake("snake.png");
        s3.setPosicao(10, 6);
        this.addPersonagem(s3);

        Bichinhoteleporta bt = new Bichinhoteleporta("pokeball.png");
        bt.setPosicao(2, 2);
        this.addPersonagem(bt);

        Muro[] muros2 = new Muro[60];

        Muro[] muros1 = new Muro[75];
        int a = 0;
        // Preencher o vetor com imagens "muro.png" nas posições especificadas
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                if ((i == 2 && j != 2 && j != 5 && j != 6 && j <= 12)
                        || (i == 4 && j >= 6 && j <= 12)
                        || (i == 9 && j >= 2 && j <= 8)
                        || (j == 13 && i >= 2 && i <= 5)
                        || (i == 11 && j >= 2 && j <= 7)
                        || (j == 11 && i >= 8 && i <= 13)
                        || (j == 13 && i >= 9 && i <= 13)
                        || (j == 9 && i >= 6 && i <= 10)
                        || (i == 1 && j == 7)
                        || (i == 3 && (j == 1 || j == 3))
                        || ((i == 4) && (j == 2))
                        || (i == 5 && j == 6)
                        || (i == 6 && (j == 6 || j == 8 || j == 9))
                        || (i == 7 && (j == 6 || j == 2 || j == 4 || j == 13 || j == 14))
                        || (i == 8 && (j == 2 || j == 4 || j == 10))
                        || (i == 10 && j == 2)
                        || (i == 13 && ((j >= 2 && j <= 4) || (j == 8) || (j == 12)))
                        || (i == 12 && j == 7)
                        || (i == 14 && (j == 2 || j == 9))) {
                    muros1[a] = new Muro("muro.png");
                    muros1[a].setPosicao(i, j);

                    this.addPersonagem(muros1[a]);
                    a++;
                }
            }

        }

        int b = 0;
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                if (j == 15 || j == 0 || i == 0 || i == 15) {
                    muros2[b] = new Muro("muro.png");
                    muros2[b].setPosicao(i, j);

                    this.addPersonagem(muros2[b]);
                    b++;
                }
            }
        }
    }

    public boolean ehPosicaoValida(Posicao p) {
        return cj.ehPosicaoValida(this.faseAtual, p);
    }

    public void addPersonagem(Personagem umPersonagem) {
        faseAtual.add(umPersonagem);
    }

    public void removePersonagem(Personagem umPersonagem) {
        faseAtual.remove(umPersonagem);
    }

    public Graphics getGraphicsBuffer() {
        return g2;
    }

    public void paint(Graphics gOld) {
        Graphics g = this.getBufferStrategy().getDrawGraphics();
        /*Criamos um contexto gráfico*/
        g2 = g.create(getInsets().left, getInsets().top, getWidth() - getInsets().right, getHeight() - getInsets().top);
        /**
         * ***********Desenha cenário de fundo*************
         */
        for (int i = 0; i < Consts.RESx; i++) {
            for (int j = 0; j < Consts.RESy; j++) {
                try {
                    if (j >= 16) {
                        Image newImage = Toolkit.getDefaultToolkit().getImage(new java.io.File(".").getCanonicalPath() + Consts.PATH + "water1.png");
                        g2.drawImage(newImage,
                                j * Consts.CELL_SIDE, i * Consts.CELL_SIDE, Consts.CELL_SIDE, Consts.CELL_SIDE, null);
                        
                    } else {
                        Image newImage = Toolkit.getDefaultToolkit().getImage(new java.io.File(".").getCanonicalPath() + Consts.PATH + "grass1.png");
                        g2.drawImage(newImage,
                                j * Consts.CELL_SIDE, i * Consts.CELL_SIDE, Consts.CELL_SIDE, Consts.CELL_SIDE, null);

                    }

                } catch (IOException ex) {
                    Logger.getLogger(Tela.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

        if (!this.faseAtual.isEmpty()) {
            this.cj.desenhaTudo(faseAtual);
            this.cj.processaTudo(faseAtual);
        }

        g.dispose();
        g2.dispose();
        if (!getBufferStrategy().contentsLost()) {
            getBufferStrategy().show();
        }
    }

    public void go() {
        TimerTask task = new TimerTask() {
            public void run() {
                repaint();
            }
        };
        Timer timer = new Timer();
        timer.schedule(task, 0, Consts.PERIOD);
    }

    public void keyPressed(KeyEvent e) {
        if (iTimer%30==0) {
            iTimer = 0;
            
            if (e.getKeyCode() == KeyEvent.VK_C) {
                this.faseAtual.clear();
            }else if(e.getKeyCode() == KeyEvent.VK_SPACE){
                this.hero.Atirar();
            }else if (e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) {
                hero.moveUp();
                this.hero.isMoving = true;
            } else if (e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_S) {
                hero.moveDown();
                this.hero.isMoving = true;
            } else if (e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A) {
                hero.moveLeft();
                this.hero.isMoving = true;
            } else if (e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D) {
                hero.moveRight();
                this.hero.isMoving = true;
            }
            this.setTitle("-> Cell: " + (hero.getPosicao().getColuna()) + ", "
                    + (hero.getPosicao().getLinha()));
            //repaint(); /*invoca o paint imediatamente, sem aguardar o refresh*/
        } else {
            System.out.println("Timer="+iTimer);
            iTimer++;
        }
    }

    public void mousePressed(MouseEvent e) {
        /* Clique do mouse desligado*/
        int x = e.getX();
        int y = e.getY();

        this.setTitle("X: "+ x + ", Y: " + y +
        " -> Cell: " + (y/Consts.CELL_SIDE) + ", " + (x/Consts.CELL_SIDE));
        this.hero.getPosicao().setPosicao(y/Consts.CELL_SIDE, x/Consts.CELL_SIDE);
        
        repaint();
    }


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("POO2023-1 - Skooter");
        setAlwaysOnTop(true);
        setAutoRequestFocus(false);
        setResizable(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 561, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

    public void mouseMoved(MouseEvent e) {
    }

    public void mouseClicked(MouseEvent e) {
    }

    public void mouseReleased(MouseEvent e) {
    }

    public void mouseEntered(MouseEvent e) {
    }

    public void mouseExited(MouseEvent e) {
    }

    public void mouseDragged(MouseEvent e) {
    }

    public void keyTyped(KeyEvent e) {
    }

    public void keyReleased(KeyEvent e) {
    }
}
