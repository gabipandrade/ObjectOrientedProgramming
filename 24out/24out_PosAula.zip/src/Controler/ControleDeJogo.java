package Controler;

import Modelo.Personagem;
import Modelo.Hero;
import Modelo.Tiro;
import Modelo.pokeball;
//import Modelo.Caveira;
import Modelo.BichinhoVaiVemHorizontal;
import Modelo.Bichinhoteleporta;
import Modelo.Muro;
import Modelo.ZigueZague;
import Modelo.snake;

import auxiliar.Posicao;
import java.util.ArrayList;

public class ControleDeJogo {
    public void desenhaTudo(ArrayList<Personagem> e){
        for(int i = 0; i < e.size(); i++){
            e.get(i).autoDesenho();
        }
    }
    public void processaTudo(ArrayList<Personagem> umaFase){
        Hero hero = (Hero)umaFase.get(0);
        Personagem tiro= umaFase.get(umaFase.size()-1);
        Personagem pIesimoPersonagem;
        for(int i = 1; i < umaFase.size(); i++){
            pIesimoPersonagem = umaFase.get(i);
            if(tiro.getPosicao().igual(pIesimoPersonagem.getPosicao()) && tiro.isbProjetil()==true && pIesimoPersonagem.isbAtiravel()==true){
                umaFase.remove(pIesimoPersonagem);
                umaFase.remove(umaFase.size()-1);
            }
            if(hero.getPosicao().igual(pIesimoPersonagem.getPosicao()))
                if(pIesimoPersonagem.isbTransponivel())
                    /*TO-DO: verificar se o personagem eh mortal antes de retsasirar*/                    
                    umaFase.remove(pIesimoPersonagem);
        }
    }
    
    /*Retorna true se a posicao p é válida para Hero com relacao a todos os personagens no array*/
    public boolean ehPosicaoValida(ArrayList<Personagem> umaFase, Posicao p){
        Personagem pIesimoPersonagem;
        for(int i = 1; i < umaFase.size(); i++){
            pIesimoPersonagem = umaFase.get(i);            
            if(!pIesimoPersonagem.isbTransponivel())
                if(pIesimoPersonagem.getPosicao().igual(p))
                    return false;
        }        
        return true;
    }
}
