/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Auxiliar.Consts;
import Auxiliar.Desenho;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.io.IOException;
import java.io.Serializable;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author rafael
 */
public class Bichinhoteleporta  extends Personagem  implements Serializable{
    private boolean bRight;
    Random rand=new Random();
    private int contaFrames;
    public Bichinhoteleporta(String sNomeImagePNG) {
        super(sNomeImagePNG);
        bRight = true;
        contaFrames=0;
        
    }
    
    public void autoDesenho(){
        contaFrames++;
        if(contaFrames==10){
            contaFrames=0;
            int NovaColuna=rand.nextInt(10);
            int NovaLinha=rand.nextInt(10);
            this.setPosicao(NovaLinha, NovaColuna);
            //aparece=!aparece;
        }
        super.autoDesenho();
        bRight = !bRight;
    }
}
