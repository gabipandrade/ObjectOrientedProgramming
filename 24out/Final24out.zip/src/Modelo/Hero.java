package Modelo;

import Auxiliar.Consts;
import Auxiliar.Desenho;
import Controler.ControleDeJogo;
import Controler.Tela;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.IOException;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;

public class Hero extends Personagem implements Serializable{
    private int Down;
    private int Up;
    private int Right;
    private int Left;
    private int Facing;
    private int Points;
    private int Life;
    public Hero(String sNomeImagePNG) {
        super(sNomeImagePNG);
        Down=1;
        Up=0;
        Right=0;
        Left=0;
        Life=3;
        Points=0;
    }

    public void voltaAUltimaPosicao(){
        this.pPosicao.volta();
    }

    public void setPoints(int Points) {
        this.Points = Points;
    }

    public int getPoints() {
        return Points;
    }

    public int getLife() {
        return Life;
    }
    
    
    public boolean setPosicao(int linha, int coluna){
        if(this.pPosicao.setPosicao(linha, coluna)){
            if (!Desenho.acessoATelaDoJogo().ehPosicaoValida(this.getPosicao())) {
                this.voltaAUltimaPosicao();
            }
            return true;
        }
        return false;       
    }

    /*TO-DO: este metodo pode ser interessante a todos os personagens que se movem*/
    private boolean validaPosicao(){
        if (!Desenho.acessoATelaDoJogo().ehPosicaoValida(this.getPosicao())) {
            this.voltaAUltimaPosicao();
            return false;
        }
        return true;       
    }
    public boolean moveUp() {
        if(super.moveUp()){
            Facing=0;
            switch (Up) {
                case 0:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer41.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Up++;
                    break;
                case 1:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer42.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Up++;
                    break;
                case 2:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer43.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Up++;
                    break;
                case 3:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer44.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Up=0;
                    break;
                default:
                    break;
            }
            return validaPosicao();
        }
            
        return false;
    }

    public boolean moveDown() {
        if(super.moveDown()){
            Facing=1;
            switch (Down) {
                case 0:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer11.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Down++;
                    break;
                case 1:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer12.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Down++;
                    break;
                case 2:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer13.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Down++;
                    break;
                case 3:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer14.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Down=0;
                    break;
                default:
                    break;
            }
            
            return validaPosicao();
        }
            
        return false;
    }

    public boolean moveRight() {
        if(super.moveRight()){
            Facing=2;
            switch (Right) {
                case 0:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer31.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Right++;
                    break;
                case 1:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer32.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Right++;
                    break;
                case 2:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer33.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Right++;
                    break;
                case 3:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer34.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Right=0;
                    break;
                default:
                    break;
            }
            return validaPosicao();
        }
        
        return false;
    }

    public boolean moveLeft() {
        if(super.moveLeft()){
            Facing=3;
            switch (Left) {
                case 0:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer23.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Left++;
                    break;
                case 1:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer22.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Left++;
                    break;
                case 2:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer23.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Left++;
                    break;
                case 3:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer24.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Left=0;
                    break;
                default:
                    break;
            }
            return validaPosicao();
        }
        return false;
    }    
    public void Atirar() {

        switch (this.Facing) {
            case 0:
                {
                    Tiro f = new Tiro("tiro0.png",0);
                    f.setPosicao(pPosicao.getLinha(),pPosicao.getColuna());
                    Desenho.acessoATelaDoJogo().addPersonagem(f);
                    break;
                }
            case 1:
                {
                    Tiro f = new Tiro("tiro11.png",1);
                    f.setPosicao(pPosicao.getLinha(),pPosicao.getColuna());
                    Desenho.acessoATelaDoJogo().addPersonagem(f);
                    break;
                }
            case 2:
                {
                    Tiro f = new Tiro("tiro1.png",2);
                    f.setPosicao(pPosicao.getLinha(),pPosicao.getColuna());
                    Desenho.acessoATelaDoJogo().addPersonagem(f);
                    break;
                }
            case 3:
                {
                    Tiro f = new Tiro("tiro3.png",3);
                    f.setPosicao(pPosicao.getLinha(),pPosicao.getColuna());
                    Desenho.acessoATelaDoJogo().addPersonagem(f);
                    break;
                }
        }
    }
}
