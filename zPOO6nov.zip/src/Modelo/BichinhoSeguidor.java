/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Auxiliar.Desenho;
import auxiliar.Posicao;
import java.io.Serializable;

/**
 *
 * @author rafael
 */
public class BichinhoSeguidor extends Personagem  implements Serializable{
    Hero h;
    private int contaFramesx;
    private int contaFramesy;
    private int Cooldown=1;
    
    public BichinhoSeguidor(String sNomeImagePNG, Hero h) {
        super(sNomeImagePNG);
        this.h=h;
        //this.bMortal=true;
    }
    private boolean validaPosicao(Posicao p){
        if (!Desenho.acessoATelaDoJogo().ehPosicaoValida(p)) {
            this.voltaAUltimaPosicao();
            return false;
        }
        return true;       
    }
    public void voltaAUltimaPosicao(){
        this.pPosicao.volta();
    }


    public void autoDesenho(){
        contaFramesx++;
        contaFramesy++;
        int y=this.pPosicao.getLinha()-h.pPosicao.getLinha();
        int x=this.pPosicao.getColuna()-h.pPosicao.getColuna();
        
        if(y>0 && contaFramesy>=Cooldown){
            if(validaPosicao(new Posicao(pPosicao.getLinha()-1,pPosicao.getColuna()))){
                this.setPosicao(pPosicao.getLinha()-1, pPosicao.getColuna());
                contaFramesy=0; 
            }
        }
        else if(y<0 && contaFramesy>=Cooldown){
            if(validaPosicao(new Posicao(pPosicao.getLinha()+1,pPosicao.getColuna()))){

                this.setPosicao(pPosicao.getLinha()+1, pPosicao.getColuna());           
                contaFramesy=0;         
            }
        }
        if(x>0 && contaFramesx>=Cooldown){
            if(validaPosicao(new Posicao(pPosicao.getLinha(),pPosicao.getColuna()-1))){
                this.setPosicao(pPosicao.getLinha(), pPosicao.getColuna()-1);
                contaFramesx=0; 
            }
        }
        else if(x<0 && contaFramesx>=Cooldown){
            if(validaPosicao(new Posicao(pPosicao.getLinha(),pPosicao.getColuna()+1))){

                this.setPosicao(pPosicao.getLinha(), pPosicao.getColuna()+1);           
                contaFramesx=0;         
            }
        }
        super.autoDesenho();
    }
    
}
/*
    if(bRight && contaFrames==1){
            if(validaPosicao(new Posicao(pPosicao.getLinha()+1,pPosicao.getColuna()))){
                this.setPosicao(pPosicao.getLinha()+1, pPosicao.getColuna());
                contaFrames=0; 
            }else{
                bRight=false;
                contaFrames=0;
            }
        }
        else if(!bRight && contaFrames==1){
            if(validaPosicao(new Posicao(pPosicao.getLinha()-1,pPosicao.getColuna()))){

                this.setPosicao(pPosicao.getLinha()-1, pPosicao.getColuna());           
                contaFrames=0;         
            }else{
                bRight=true;
                contaFrames=0;
            }
        }    
        super.autoDesenho();
    }
    
*/