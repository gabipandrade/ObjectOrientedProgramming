package Modelo;

import Auxiliar.Consts;
import Auxiliar.Desenho;
import auxiliar.Posicao;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.io.IOException;
import java.io.Serializable;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class BichinhoVaiVemHorizontal extends Personagem  implements Serializable{
    private boolean bRight;
    private int contaFrames;
    public BichinhoVaiVemHorizontal(String sNomeImagePNG) {
        super(sNomeImagePNG);
        bRight = true;
        this.bMortal=true;
    }

    private boolean validaPosicao(Posicao p){
        if (!Desenho.acessoATelaDoJogo().ehPosicaoValida(p)) {
            this.voltaAUltimaPosicao();
            return false;
        }
        return true;       
    }
    public void voltaAUltimaPosicao(){
        this.pPosicao.volta();
    }
    
    public void autoDesenho(){
        contaFrames++;
        if(bRight && contaFrames==1){
            if(validaPosicao(new Posicao(pPosicao.getLinha(),pPosicao.getColuna()+1))){
                this.setPosicao(pPosicao.getLinha(), pPosicao.getColuna()+1);
                contaFrames=0; 
            }else{
                bRight=false;
                contaFrames=0;
            }
        }
        else if(!bRight && contaFrames==1){
            if(validaPosicao(new Posicao(pPosicao.getLinha(),pPosicao.getColuna()-1))){

                this.setPosicao(pPosicao.getLinha(), pPosicao.getColuna()-1);           
                contaFrames=0;         
            }else{
                bRight=true;
                contaFrames=0;
            }
        }    
        super.autoDesenho();
    }
    
}
