/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fases;

import Controler.Tela;
import Modelo.BichinhoSeguidor;
import Modelo.BichinhoVaiVemCima;
import Modelo.BichinhoVaiVemHorizontal;
import Modelo.Bichinhoteleporta;
import Modelo.Caveira;
import Modelo.Heart;
import Modelo.Muro;
import Modelo.Tree;
import Modelo.pokeball;
import Modelo.snake;


/**
 *
 * @author rafael
 */
public class Fases {

    public static void Fase1(Tela t){
        t.getHero().setPosicao(14, 5);
        
        
        pokeball pb1 = new pokeball("pokeballb.png");
        pb1.setPosicao(3, 2);
        t.addPersonagem(pb1);

        pokeball pb2 = new pokeball("pokeball.png");
        pb2.setPosicao(10, 3);
        t.addPersonagem(pb2);

        pokeball pb3 = new pokeball("pokeball.png");
        pb3.setPosicao(3, 12);
        t.addPersonagem(pb3);

        pokeball pb4 = new pokeball("pokeball.png");
        pb4.setPosicao(12, 12);
        t.addPersonagem(pb4);

        snake s1 = new snake("snake.png");
        s1.setPosicao(3, 7);
        t.addPersonagem(s1);

        snake s2 = new snake("snake.png");
        s2.setPosicao(5, 14);
        t.addPersonagem(s2);

        snake s3 = new snake("snake.png");
        s3.setPosicao(10, 6);
        t.addPersonagem(s3);

        Bichinhoteleporta bt = new Bichinhoteleporta("pokeball.png");
        bt.setPosicao(2, 2);
        t.addPersonagem(bt);

        Muro[] muros2 = new Muro[60];
        
        Tree[] muros1 = new Tree[75];
        int a = 0;
        int c=0;
        // Preencher o vetor com imagens "muro.png" nas posições especificadas
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                if ((i == 2 && j != 2 && j != 5 && j != 6 && j <= 12)
                        || (i == 4 && j >= 6 && j <= 12)
                        || (i == 9 && j >= 2 && j <= 8)
                        || (j == 13 && i >= 2 && i <= 5)
                        || (i == 11 && j >= 2 && j <= 7)
                        || (j == 11 && i >= 8 && i <= 13)
                        || (j == 13 && i >= 9 && i <= 13)
                        || (j == 9 && i >= 6 && i <= 10)
                        || (i == 1 && j == 7)
                        || (i == 3 && (j == 1 || j == 3))
                        || ((i == 4) && (j == 2))
                        || (i == 5 && j == 6)
                        || (i == 6 && (j == 6 || j == 8 || j == 9))
                        || (i == 7 && (j == 6 || j == 2 || j == 4 || j == 13 || j == 14))
                        || (i == 8 && (j == 2 || j == 4 || j == 10))
                        || (i == 10 && j == 2)
                        || (i == 13 && ((j >= 2 && j <= 4) || (j == 8) || (j == 12)))
                        || (i == 12 && j == 7)
                        || (i == 14 && (j == 2 || j == 9))) {
                    switch(c){
                        case 0:
                            muros1[a] = new Tree("tree1.png");
                            c++;
                            break;
                        case 1:
                            muros1[a] = new Tree("tree3.png");
                            c++;
                            break;
                        case 2:
                            muros1[a] = new Tree("tree3.png");
                            c=0;
                            break;
                    }
                    muros1[a].setPosicao(i, j);
                    t.addPersonagem(muros1[a]);
                    a++;
                }
            }

        }

        int b = 0;
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                if (j == 15 || j == 0 || i == 0 || i == 15) {
                    muros2[b] = new Muro("muro.png");
                    muros2[b].setPosicao(i, j);

                    t.addPersonagem(muros2[b]);
                    b++;
                }
            }
        }
        
    }
    public static void Fase2(Tela t){
        t.getHero().setPosicao(13,5);
        /*Cria faseAtual adiciona personagens*/
        
        /*
        Caveira bV1 = new Caveira("caveira.png");
        bV1.setPosicao(5, 1);
        faseAtual.add(bV1);
        
        Caveira bV2 = new Caveira("caveira.png");
        bV2.setPosicao(6, 1);
        this.addPersonagem(bV2);
        
        Caveira bV3 = new Caveira("caveira.png");
        bV3.setPosicao(7, 1);
        this.addPersonagem(bV3);
        */
        snake s1 = new snake("snake.png");
        s1.setPosicao(12, 11);
        t.addPersonagem(s1);

        snake s2 = new snake("snake.png");
        s2.setPosicao(12, 10);
        t.addPersonagem(s2);
        
        snake s3 = new snake("snake.png");
        s3.setPosicao(4, 5);
        t.addPersonagem(s3);

        snake s4 = new snake("snake.png");
        s4.setPosicao(3, 5);
        t.addPersonagem(s4);
        
        snake s5 = new snake("snake.png");
        s5.setPosicao(2, 5);
        t.addPersonagem(s5);
        
        snake s7 = new snake("snake.png");
        s7.setPosicao(3, 7);
        t.addPersonagem(s7);

        BichinhoVaiVemHorizontal bBichinhoH = new BichinhoVaiVemHorizontal("roboPink.png");
        bBichinhoH.setPosicao(14, 1);
        t.addPersonagem(bBichinhoH);

        BichinhoVaiVemCima bc1 = new BichinhoVaiVemCima("roboPink.png");
        bc1.setPosicao(1, 1);
        t.addPersonagem(bc1);

        BichinhoVaiVemCima bc2 = new BichinhoVaiVemCima("roboPink.png");
        bc2.setPosicao(1, 14);
        t.addPersonagem(bc2);

        
        Bichinhoteleporta bt = new Bichinhoteleporta("pokeball.png");
        bt.setPosicao(2, 2);
        t.addPersonagem(bt);
        
        pokeball pb1 = new pokeball("pokeball.png");
        pb1.setPosicao(1, 5);
        t.addPersonagem(pb1);

        pokeball pb2 = new pokeball("pokeball.png");
        pb2.setPosicao(5, 7);
        t.addPersonagem(pb2);

        pokeball pb3 = new pokeball("pokeball.png");
        pb3.setPosicao(7, 11);
        t.addPersonagem(pb3);
        
        pokeball pb4 = new pokeball("pokeball.png");
        pb4.setPosicao(4, 7);
        t.addPersonagem(pb4);
        
        pokeball pb5 = new pokeball("pokeball.png");
        pb5.setPosicao(11, 10);
        t.addPersonagem(pb5);

        pokeball pb6 = new pokeball("pokeball.png");
        pb6.setPosicao(11, 11);
        t.addPersonagem(pb6);

        
        Muro[] muros2 = new Muro[60];
        Tree[] muros1 = new Tree[60];
        
        int a = 0;
        int c=0;
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                if (((j==4||j==3) && (i>=1 && i<=4))
                    ||(j==6 &&(i>=1 && i<=6))
                    //||(j==13 && (i==1 ||i==2))
                    ||((j==8||j==9)&&(i>=3 && i<=6))
                    ||(j==12 &&((i>=5 &&i<=12 )||i==1 ||i==2))
                    ||(i==10 &&(j>=2 &&j<=5))
                    ||(i==11 &&(j==2 || j==5))
                    ||(j==8 &&(i>=9 &&i<=12))
                    ||(j==9 && (i>=11 && i<=13))
                    ||(j==11 && i==4)
                    ||(i==12 && (j>=5 &&j<=7))
                    ||(i==6 && j==7)
                    ||(i==3 && j==10)
                    ||(i==10 && (j>=10 && j<=11))) {
                    switch(c){
                        case 0:
                            muros1[a] = new Tree("arvore1.png");
                            c++;
                            break;
                        case 1:
                            muros1[a] = new Tree("arvore2.png");
                            c=0;
                            break;
                    }
                    muros1[a].setPosicao(i, j);

                    t.addPersonagem(muros1[a]);
                    a++;
                }
            }
        }
        
        // Preencher o vetor com imagens "muro.png" nas posições especificada
        int b = 0;
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                if (j == 15 || j == 0 || i == 0 || i == 15) {
                    muros2[b] = new Muro("muro.png");
                    muros2[b].setPosicao(i, j);

                    t.addPersonagem(muros2[b]);
                    b++;
                }
            }
        }
            
    }
    public static void Fase3(Tela t){
       t.getHero().setPosicao(14,5);
        /*Cria faseAtual adiciona personagens*/
        
        Caveira bV1 = new Caveira("caveira.png");
        bV1.setPosicao(1, 1);
        t.addPersonagem(bV1);
        
        Caveira bV2 = new Caveira("caveira.png");
        bV2.setPosicao(4, 3);
        t.addPersonagem(bV2);
        
        Caveira bV3 = new Caveira("caveira.png");
        bV3.setPosicao(1, 14);
        t.addPersonagem(bV3);
        
        Caveira bV4 = new Caveira("caveira.png");
        bV4.setPosicao(4, 12);
        t.addPersonagem(bV4);
        
        BichinhoVaiVemCima bc1 = new BichinhoVaiVemCima("roboPink.png");
        bc1.setPosicao(5, 6);
        t.addPersonagem(bc1);
        
        BichinhoVaiVemCima bc2 = new BichinhoVaiVemCima("roboPink.png");
        bc2.setPosicao(9, 9);
        t.addPersonagem(bc2);
       
        Bichinhoteleporta bt = new Bichinhoteleporta("pokeball.png");
        bt.setPosicao(2, 2);
        t.addPersonagem(bt);
        
        pokeball pb1 = new pokeball("pokeballb.png");
        pb1.setPosicao(4, 4);
        t.addPersonagem(pb1);
        
        pokeball pb2 = new pokeball("pokeball.png");
        pb2.setPosicao(13, 7);
        t.addPersonagem(pb2);
        
        pokeball pb3 = new pokeball("pokeball.png");
        pb3.setPosicao(2, 12);
        t.addPersonagem(pb3);

        pokeball pb4 = new pokeball("pokeball.png");
        pb4.setPosicao(1, 5);
        t.addPersonagem(pb4);
        
        pokeball pb5 = new pokeball("pokeball.png");
        pb5.setPosicao(13, 9);
        t.addPersonagem(pb5);
        
        Muro[] muros2 = new Muro[60];
        // Preencher o vetor com imagens "muro.png" nas posições especificada
        Muro[] muros1 = new Muro[99];
        int a = 0;
        // Preencher o vetor com imagens "muro.png" nas posições especificadas
        /*
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                if ((j==2 && (i==3||i==6||i==8))
                    ||(j==13 && (i==6||i==8||i==10||i==13))
                    ||(j==9&&!(i>=1&&i<=3)&&i!=8)
                    ||(i==4&&!(j>=1&&j<=3)&&!(j>=12&&j<=14)&&j!=9)
                    ||(i==11&&!(j>=1&&j<=3)&&j!=8&&!(j>=12&&j<=14))
                    ||(j==8 &&!(i>=1&&i<=3)&&!(i>=12&&i<=14)&& i!=8)
                    ||(j==7&&(i==1||i==2||i==3||i==4))){
                    muros1[a] = new Muro("muro.png");
                    muros1[a].setPosicao(i, j);
                    this.addPersonagem(muros1[a]);
                    a++;
                }
            }     
        }
        */
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                if (j==2 &&(i==3||i==6||i==9)
                        ||(j==13 &&(i==6||i==8||i==10||i==13))
                        ||(i==4&&(j>=4&&j<=11))
                        ||(i==11&&(j>=4&&j<=11))
                        ||(j==6&&(i>=1&&i<=3))
                        ||(j==7&&((i>=5&&i<=7)||i==9||i==10))
                        ||(j==8&&((i>=5&&i<=7)||i==9||i==10||i==12||i==13||i==14))
                        
                        ){
                    muros1[a] = new Muro("tree.png");
                    muros1[a].setPosicao(i, j);
                    t.addPersonagem(muros1[a]);
                    a++;
                }
            }     
        }
        // Preencher o vetor com imagens "muro.png" nas posições especificada
        int b = 0;
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                if (j == 15 || j == 0 || i == 0 || i == 15) {
                    muros2[b] = new Muro("muro.png");
                    muros2[b].setPosicao(i, j);

                    t.addPersonagem(muros2[b]);
                    b++;
                }
            }
        }
        
    }
    public static void Fase4(Tela t){
       t.getHero().setPosicao(14,5);
        /*Cria faseAtual adiciona personagens*/
        Bichinhoteleporta bt = new Bichinhoteleporta("pokeball.png");
        bt.setPosicao(2, 2);
        t.addPersonagem(bt);
        pokeball pb1 = new pokeball("pokeballb.png");
        pb1.setPosicao(3, 8);
        t.addPersonagem(pb1);

        pokeball pb2 = new pokeball("pokeball.png");
        pb2.setPosicao(4, 5);
        t.addPersonagem(pb2);

        pokeball pb3 = new pokeball("pokeball.png");
        pb3.setPosicao(9, 1);
        t.addPersonagem(pb3);

        pokeball pb4 = new pokeball("pokeball.png");
        pb4.setPosicao(12, 12);
        t.addPersonagem(pb4);
        
        Muro m1=new Muro("muro.png");
        m1.setPosicao(10, 4);
        t.addPersonagem(m1);
        
        Muro m2=new Muro("muro.png");
        m2.setPosicao(4, 10);
        t.addPersonagem(m2);
        
        Muro[] muros2 = new Muro[60];
        BichinhoVaiVemHorizontal[]bH=new BichinhoVaiVemHorizontal[14]; 
        int c=0;
        for(int i=1;i<15;i++){
            bH[c] = new BichinhoVaiVemHorizontal("roboPink.png");
            bH[c].setPosicao(i, 0);
            t.addPersonagem(bH[c]);
            c++;
        }
        // Preencher o vetor com imagens "muro.png" nas posições especificada
        int b = 0;
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                if (j == 15 || j == 0 || i == 0 || i == 15) {
                    muros2[b] = new Muro("muro.png");
                    muros2[b].setPosicao(i, j);

                    t.addPersonagem(muros2[b]);
                    b++;
                }
            }
        }
        
    }
    public static void Fase5(Tela t){
       t.getHero().setPosicao(14,5);
        /*Cria faseAtual adiciona personagens*/
        Bichinhoteleporta bt = new Bichinhoteleporta("pokeball.png");
        bt.setPosicao(2, 2);
        t.addPersonagem(bt);
        
        Bichinhoteleporta bt1 = new Bichinhoteleporta("pokeball.png");
        bt.setPosicao(5, 1);
        t.addPersonagem(bt1);
        
        Bichinhoteleporta bt2 = new Bichinhoteleporta("pokeball.png");
        bt.setPosicao(1, 5);
        t.addPersonagem(bt2);
        
        BichinhoSeguidor b1=new BichinhoSeguidor("robo.png",t.getHero());
        b1.setPosicao(6, 6);
        t.addPersonagem(b1);
        
        BichinhoSeguidor b2=new BichinhoSeguidor("robo.png",t.getHero());
        b2.setPosicao(1, 14);
        t.addPersonagem(b2);
                
        /*        
        Muro[] muros1 = new Muro[5];
        int a=0;
        for(int i=0;i<5;i++){
            muros1[a] = new Muro("muro.png");
            muros1[a].setPosicao(10, 5+i);

            t.addPersonagem(muros1[a]);
            a++;
            
        }
        */
        Tree[] muros1 = new Tree[99];
        int a=0;
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                if ((i == 2 && j != 2 && j != 5 && j != 6 && j <= 12)
                        || (i == 4 && j >= 6 && j <= 12)
                        || (i == 9 && j >= 2 && j <= 8)
                        || (j == 13 && i >= 2 && i <= 5)
                        || (i == 11 && j >= 2 && j <= 7)
                        || (j == 11 && i >= 8 && i <= 13)
                        || (j == 13 && i >= 9 && i <= 13)
                        || (j == 9 && i >= 6 && i <= 10)
                        || (i == 1 && j == 7)
                        || (i == 3 && (j == 1 || j == 3))
                        || ((i == 4) && (j == 2))
                        || (i == 5 && j == 6)
                        || (i == 6 && (j == 6 || j == 8 || j == 9))
                        || (i == 7 && (j == 6 || j == 2 || j == 4 || j == 13 || j == 14))
                        || (i == 8 && (j == 2 || j == 4 || j == 10))
                        || (i == 10 && j == 2)
                        || (i == 13 && ((j >= 2 && j <= 4) || (j == 8) || (j == 12)))
                        || (i == 12 && j == 7)
                        || (i == 14 && (j == 2 || j == 9))) {
                    muros1[a] = new Tree("tree.png");
                    
                    muros1[a].setPosicao(i, j);
                    t.addPersonagem(muros1[a]);
                    a++;
                }
            }
        }
        Muro[] muros2 = new Muro[60];
        // Preencher o vetor com imagens "muro.png" nas posições especificada
        
        // Preencher o vetor com imagens "muro.png" nas posições especificada
        int b = 0;
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                if (j == 15 || j == 0 || i == 0 || i == 15) {
                    muros2[b] = new Muro("muro.png");
                    muros2[b].setPosicao(i, j);

                    t.addPersonagem(muros2[b]);
                    b++;
                }
            }
        }
        
    }
    public static void GameOver(Tela t){
        t.getHero().setPosicao(14,5);
       
        Muro[] muros1 = new Muro[134];
        int a = 0;
        // Preencher o vetor com imagens "muro.png" nas posições especificadas
        
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 22; j++) {
                if ((i == 0 && j<=22 && j!=5 && j!=11 &&j!=14 &&j!=17)
                        ||(i==1&&(j==0||j==6||j==10||j==12||j==14||j==16||j==18))
                        ||(i==2&&(j==0||j==6||j==10||j==12||j==14||j==16||j==18||j==19||j==20||j==21))
                        ||(i==3 && j<=22 && j!=1 && j!=5 && j!=11 &&j!=13 &&j!=14 &&j!=15 &&j!=17 &&j<=18)
                        ||(i==4&&(j==0||j==4||j==6||j==10||j==12||j==16||j==18))
                        ||(i== 5 && j<=22 && j!=5 && j!=11 &&j!=14 &&j!=17 &&j!=7&&j!=8&&j!=9&&j!=13&&j!=14&&j!=15)
                        ||(i == 8 && j<=22 && j!=5 && !(j>=7 && j<=9)&& j!=11 &&j!=16&&j!=7&&j!=8&&j!=9)
                        ||(i==9&&(j==0||j==4||j==6||j==10||j==12||j==17||j==21))
                        ||(i==10&&(j==0||j==4||j==6||j==10||j==12||j==13||j==14||j==15||j==17||j==21))
                        ||(i==11 && j<=22 && j!=5 && !(j>=7 && j<=9)&&!(j>=1 &&j<=3)&&!(j>=13 &&j<=16)&& j!=11&& j!=7&&j!=8&&j!=9)
                        ||(i==12&&(j==0||j==4||j==6||j==10||j==12||j==17||j==20))
                        ||(i==13&&j<=22&&j!=5&&j!=11&&j!=16&&j!=18 && j!=19)
                        ){
                    muros1[a] = new Muro("muro.png");
                    muros1[a].setPosicao(i, j);

                    t.addPersonagem(muros1[a]);
                    a++;
                }
            }
        }
    }
    
}
