package Controler;

import Modelo.pokeball;
import Modelo.Personagem;
import Modelo.Caveira;
import Modelo.Hero;
import Modelo.BichinhoVaiVemHorizontal;
import Modelo.Bichinhoteleporta;
import Modelo.Muro;
import Modelo.ZigueZague;
import Modelo.snake;
import Modelo.Tiro;

import auxiliar.Posicao;
import Auxiliar.Consts;
import static Auxiliar.Consts.*;
import Auxiliar.Desenho;
import Modelo.BichinhoVaiVemCima;
import Fases.Fases;
import Modelo.Heart;
import Modelo.Tree;
import data.SaveLoad;

//import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;

//import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
import java.io.IOException;
//import java.io.ObjectInputStream;
//import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
//import java.util.zip.GZIPInputStream;
//import java.util.zip.GZIPOutputStream;
//import javax.swing.JButton;

public class Tela extends javax.swing.JFrame implements MouseListener, KeyListener{

    private Hero hero;
    private ArrayList<Personagem> faseAtual;
    private ControleDeJogo cj = new ControleDeJogo();
    private SaveLoad saveLoad;
    private Fases fases;
    private int FPS;
    private int UPS;
    private Graphics g2;
    private int iTimer;
    private final int FPS_SET=15;
    private final int UPS_SET=15;
    
    
    public Tela() {
        System.out.println("Bem vindo ao Jogo XXXXX");
        System.out.println("Para controlar seu personagem mova-se no WASD ou nas setas");
        System.out.println("Para atirar use espaco");
        System.out.println("Para salvar utilize K e para dar Load utilize L");
        System.out.println("Para resetar a fase utilize R");
        System.out.println("Para pular a fase utilize F");
        System.out.println("Para bugar o jogo, clique C");
        iTimer = 0;
        FPS=0;
        UPS=0;
        saveLoad= new SaveLoad(this);
        Desenho.setCenario(this);
        initComponents();
        this.addMouseListener(this);
        /*mouse*/
        this.addKeyListener(this);
        /*teclado*/

 /*Cria a janela do tamanho do tabuleiro + insets (bordas) da janela*/
        this.setSize(Consts.RESy * Consts.CELL_SIDE + getInsets().left + getInsets().right,
                Consts.RESx * Consts.CELL_SIDE + getInsets().top + getInsets().bottom);

        faseAtual = new ArrayList<Personagem>();
        
        
        /*Cria faseAtual adiciona personagens*/
        hero = new Hero("btrainer11.png");
        
        this.addPersonagem(hero);
        
        hero.setPosicao(14, 5);
        UpdateHealth();
        Fases.Fase1(this);
        
    }
    
    private void LimpaTela(){
        Personagem pIesimoPersonagem;
        //while(faseAtual.size()!=1){
            //for(int i = 1; i < faseAtual.size(); i++){
            //    pIesimoPersonagem = faseAtual.get(i);
            //    faseAtual.remove(pIesimoPersonagem);
            //}
            Hero h = (Hero)faseAtual.get(0);
            faseAtual.clear();
            faseAtual.add(h);
        //}
        
        
    }
    private void Reset() {
        LimpaTela();
        if(hero.getFase()==1){
            UpdateHealth();
            hero.setBalas(0);
            hero.setLife(5);
            hero.setPoints(0);
            Fases.Fase1(this);
        }else if(hero.getFase()==2){
            int delay=0;
            for(int i=0;i<60;i++){
                delay++;
                //System.out.println("Delay Para iniciar fase "+ (Fase+1) +" = "+(60-delay));
            }
            UpdateHealth();
            hero.setBalas(0);
            hero.setLife(5);
            hero.setPoints(0);
            Fases.Fase2(this);
        }else if(hero.getFase()==3){
            int delay=0;
            UpdateHealth();
            for(int i=0;i<60;i++){
                delay++;
                //System.out.println("Delay Para iniciar fase "+ (Fase+1) +" = "+(60-delay));
            }
            UpdateHealth();
            hero.setBalas(0);
            hero.setLife(5);
            hero.setPoints(0);
            Fases.Fase3(this);
        }else if(hero.getFase()==4){
            int delay=0;
            for(int i=0;i<60;i++){
                delay++;
                //System.out.println("Delay Para iniciar fase "+ (Fase+1) +" = "+(60-delay));
            }
            UpdateHealth();
            hero.setBalas(0);
            hero.setLife(5);
            hero.setPoints(0);
            Fases.Fase4(this);
        }else if(hero.getFase()==5){
            int delay=0;
            for(int i=0;i<60;i++){
                delay++;
            }
            UpdateHealth();
            hero.setBalas(0);
            hero.setLife(5);
            hero.setPoints(0);
            Fases.Fase5(this);
        
        }else if(hero.getFase()==6){
            hero.setBalas(0);
            hero.setPoints(0);
            Fases.GameOver(this);
        }
        
    }
    public void UpdateHealth(){
        Heart[] h= new Heart[5];
        for(int i=0;i<5;i++){
            h[i] =new Heart("Heart.png");
            h[i].setPosicao(2,16+i);
            this.addPersonagem(h[i]);
        }
        
        
    }
    
    public int pontosdaFase(){
        if(hero.getFase()==2)
            return 6;
        else
            return 3;
    }
    public boolean ehPosicaoValida(Posicao p) {
        return cj.ehPosicaoValida(this.faseAtual, p);
    }

    public void addPersonagem(Personagem umPersonagem) {
        faseAtual.add(umPersonagem);
    }

    public void removePersonagem(Personagem umPersonagem) {
        faseAtual.remove(umPersonagem);
    }

    public Graphics getGraphicsBuffer() {
        return g2;
    }

    public void paint(Graphics gOld) {
        Graphics g = this.getBufferStrategy().getDrawGraphics();
        /*Criamos um contexto gráfico*/
        g2 = g.create(getInsets().left, getInsets().top, getWidth() - getInsets().right, getHeight() - getInsets().top);
        /**
         * ***********Desenha cenário de fundo*************
         */
        hero.updateAnimationTick();
        BackGround();
        
        if (!this.faseAtual.isEmpty()) {
            this.cj.desenhaTudo(faseAtual);
            this.cj.processaTudo(faseAtual);
        }
        
        //hero.render(g);
        
        g.dispose();
        g2.dispose();
        if (!getBufferStrategy().contentsLost()) {
            getBufferStrategy().show();
        }
        if(hero.getLife()<=0){
            LimpaTela();
            Fases.GameOver(this);
            hero.setLife(5);
        }
        if(faseAtual.size()==1 && hero.getFase()==1){
            int delay=0;
            //delay
            for(int i=0;i<60;i++){
                delay++;
                //System.out.println("Delay Para iniciar fase "+ (Fase+1) +" = "+(60-delay));
            }
            hero.setPoints(0);
            UpdateHealth();
            hero.setLife(5);
            Fases.Fase2(this);
            hero.setFase(2);
        }else if(faseAtual.size()==1 && hero.getFase()==2){
            int delay=0;
            //delay
            for(int i=0;i<60;i++){
                delay++;
                //System.out.println("Delay Para iniciar fase "+ (Fase+1) +" = "+(60-delay));
            }
            hero.setPoints(0);
            UpdateHealth();
            hero.setLife(5);
            Fases.Fase3(this);
            hero.setFase(3);
        }else if(faseAtual.size()==1 && hero.getFase()==3){
            int delay=0;
            //delay
            for(int i=0;i<60;i++){
                delay++;
                //System.out.println("Delay Para iniciar fase "+ (Fase+1) +" = "+(60-delay));
            }
            
            hero.setPoints(0);
            hero.setLife(5);
            UpdateHealth();
            Fases.Fase4(this);
            hero.setFase(4);
        }else if(faseAtual.size()==1 && hero.getFase()==4){
            int delay=0;
            for(int i=0;i<60;i++){
                delay++;
            }
            
            hero.setPoints(0);
            hero.setLife(5);
            UpdateHealth();
            Fases.Fase5(this);
            hero.setFase(5);
        
        }else if(faseAtual.size()==1 && hero.getFase() ==5){
            hero.setPoints(0);
            Fases.GameOver(this);
            hero.setFase(6);
        }
        if(hero.getFase()<=4){
            this.setTitle("Fase "+hero.getFase()+ "\tPontos :"+ hero.getPoints()+"/"+pontosdaFase()+"\tVida :"+hero.getLife()+"/5"+"\tBalas :"+hero.getBalas()+"\tFPS: "+FPS+" | UPS:"+UPS);
        }else if(hero.getFase()==5){
            this.setTitle("Fase Bonus!\tPontos :"+ hero.getPoints()+ "/"+pontosdaFase()+"\tVida:"+hero.getLife()+"/5"+"\tFPS: "+FPS+" | UPS:"+UPS);
        }else{
            this.setTitle("Game Over, Thanks for Playing!");
        
        }
    }
    
    public void keyPressed(KeyEvent e) {            
            if (e.getKeyCode() == KeyEvent.VK_C) {
                this.faseAtual.clear();
            }else if(e.getKeyCode() == KeyEvent.VK_R){
                Reset();
            }else if(e.getKeyCode() == KeyEvent.VK_F){
                hero.setPosicao(0, 8);
                hero.setPoints(pontosdaFase());
                
            }else if(e.getKeyCode()==KeyEvent.VK_K){
                saveLoad.save();
                System.out.println("O progresso do jogo foi salvo!");
            }else if(e.getKeyCode()==KeyEvent.VK_L){
                saveLoad.load();
                System.out.println("Jogo foi carregado com sucesso!");
                Reset();
            }
            if(!hero.getPosicao().igual(new Posicao(0,8))){
                if(e.getKeyCode() == KeyEvent.VK_SPACE){
                        this.hero.Atirar();
                }else if (e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) {
                    //hero.setDirection(UP);
                    //hero.moveUp();
                    hero.setPlayerDir(UP);
                    hero.setUp(true);

                } else if (e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_S) {
                    //hero.setDirection(DOWN);
                    //hero.moveDown();
                    hero.setPlayerDir(DOWN);
                    hero.setDown(true);

                } else if (e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A) {
                    //hero.setDirection(LEFT);
                    //hero.moveLeft();
                    hero.setPlayerDir(LEFT);
                    hero.setLeft(true);

                } else if (e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D) {
                    //hero.setDirection(RIGHT);                
                    //hero.moveRight();
                    hero.setPlayerDir(RIGHT);
                    hero.setRight(true);

                }       
            }
            //this.setTitle("-> Cell: " + (hero.getPosicao().getColuna()) + ", "
            //      + (hero.getPosicao().getLinha()));
            //repaint(); /*invoca o paint imediatamente, sem aguardar o refresh*/
        
    }
    
    public void mousePressed(MouseEvent e) {
        /* Clique do mouse desligado*/
        int x = e.getX();
        int y = e.getY();

        //this.setTitle("X: "+ x + ", Y: " + y +
        //" -> Cell: " + (y/Consts.CELL_SIDE) + ", " + (x/Consts.CELL_SIDE));
        this.hero.getPosicao().setPosicao(y/Consts.CELL_SIDE, x/Consts.CELL_SIDE);
        
       //repaint();
    }


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("POO2023-1 - Skooter");
        setAlwaysOnTop(true);
        setAutoRequestFocus(false);
        setResizable(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 561, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

    public void mouseMoved(MouseEvent e) {
    }

    public void mouseClicked(MouseEvent e) {
    }

    public void mouseReleased(MouseEvent e) {
    }

    public void mouseEntered(MouseEvent e) {
    }

    public void mouseExited(MouseEvent e) {
    }

    public void mouseDragged(MouseEvent e) {
    }

    public void keyTyped(KeyEvent e) {
        
    }

    public void keyReleased(KeyEvent e) {
        switch(e.getKeyCode()){
            case KeyEvent.VK_W :
            case KeyEvent.VK_UP:    
                hero.setUp(false);
                break;
            case KeyEvent.VK_A:
            case KeyEvent.VK_LEFT:
                hero.setLeft(false);
                break;
            case KeyEvent.VK_S:
            case KeyEvent.VK_DOWN:
                hero.setDown(false);
                break;
            case KeyEvent.VK_D:
            case KeyEvent.VK_RIGHT:
                hero.setRight(false);
                break;
        }
    }
    
    public void update(){
        hero.update();
    }
    
    public void go() {
        TimerTask task = new TimerTask() {
            public void run() {
                double timePerFrame = 1000000000.0/FPS_SET;
                double timePerUpdate=1000000000.0/UPS_SET;

                long previousTime=System.nanoTime();


                int frames=0;
                int updates=0;
                long lastCheck=System.currentTimeMillis();

                double deltaU=0;
                double deltaF=0;
                while(true){
                    long currentTime=System.nanoTime();

                    deltaU+=(currentTime-previousTime)/timePerUpdate;
                    deltaF+=(currentTime-previousTime)/timePerFrame;

                    previousTime=currentTime;
                    if(deltaU>=1){
                        update();
                        updates++;
                        deltaU--;
                    }
                    if(deltaF>=1){
                        repaint();               
                        frames++;
                        deltaF--;
                    }
                    if(System.currentTimeMillis()- lastCheck >=1000){
                        lastCheck=System.currentTimeMillis();
                        FPS=frames;
                        UPS=updates;
                        //System.out.println("FPS: "+frames+" | UPS:"+updates);
                        frames=0;
                        updates=0;
                    }
                }
            }
        };
        Timer timer = new Timer();
        timer.schedule(task, 0, Consts.PERIOD);
    }

    public Hero getHero() {
        return hero;
    }

    private void BackGround() {
        for (int i = 0; i < Consts.RESx; i++) {
            for (int j = 0; j < Consts.RESy; j++) {
                try {
                    if (j >= 16) {
                        Image newImage = Toolkit.getDefaultToolkit().getImage(new java.io.File(".").getCanonicalPath() + Consts.PATH + "grass1.png");
                        g2.drawImage(newImage,
                                j * Consts.CELL_SIDE, i * Consts.CELL_SIDE, Consts.CELL_SIDE, Consts.CELL_SIDE, null);
                        
                    } else if(i==0 && j==8){
                        Image newImage = Toolkit.getDefaultToolkit().getImage(new java.io.File(".").getCanonicalPath() + Consts.PATH + "seta.png");
                        g2.drawImage(newImage,
                                j * Consts.CELL_SIDE, i * Consts.CELL_SIDE, Consts.CELL_SIDE, Consts.CELL_SIDE, null);
                        
                    }else {
                        Image newImage = Toolkit.getDefaultToolkit().getImage(new java.io.File(".").getCanonicalPath() + Consts.PATH + "grass1.png");
                        g2.drawImage(newImage,
                                j * Consts.CELL_SIDE, i * Consts.CELL_SIDE, Consts.CELL_SIDE, Consts.CELL_SIDE, null);

                    }

                } catch (IOException ex) {
                    Logger.getLogger(Tela.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

    }

    
    
}
