package Modelo;

import Auxiliar.Consts;
import static Auxiliar.Consts.*;

import Auxiliar.Desenho;
import Controler.ControleDeJogo;
import Controler.Tela;
import auxiliar.Posicao;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.IOException;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.Timer;

public class Hero extends Personagem implements Serializable{
    //CONTROLE
    private int Down;
    private int Up;
    private int Right;
    private int Left;
    private int Facing;
    private int Points;
    private int aniTick,aniIndex,aniSpeed=15;
    private int playerDir=-1;
    private boolean moving=false;
    private boolean left,up,right,down;
    
    //VISUAL
    private BufferedImage img;
    private BufferedImage[][] animations;
    private int playerAction=RUNNINGUP;
    //ATRIBUTOS
    private int Life;
    
    public Hero(String sNomeImagePNG) {
        super(sNomeImagePNG);
        Down=1;
        Up=0;
        Right=0;
        Left=0;
        Life=3;
        Points=0;
        
    }

   
    public void voltaAUltimaPosicao(){
        this.pPosicao.volta();
    }

    public void setPoints(int Points) {
        this.Points = Points;
    }

    public int getPoints() {
        return Points;
    }

    public int getLife() {
        return Life;
    }

    public void setLife(int Life) {
        this.Life = Life;
    }
    
    
    public boolean setPosicao(int linha, int coluna){
        if(this.pPosicao.setPosicao(linha, coluna)){
            if (!Desenho.acessoATelaDoJogo().ehPosicaoValida(this.getPosicao())) {
                this.voltaAUltimaPosicao();
            }
            return true;
        }
        return false;       
    }

    /*TO-DO: este metodo pode ser interessante a todos os personagens que se movem*/
    private boolean validaPosicao(){
        if (!Desenho.acessoATelaDoJogo().ehPosicaoValida(this.getPosicao())) {
            this.voltaAUltimaPosicao();
            return false;
        }
        return true;       
    }
    
    public boolean moveUp() {
        if(super.moveUp()){
            Facing=0;
            if(moving){
                switch (Up) {
                case 0:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer41.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Up++;
                    break;
                case 1:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer42.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Up++;
                    break;
                case 2:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer43.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Up++;
                    break;
                case 3:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer44.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Up=0;
                    break;
                default:
                    break;
                }
            }
            return validaPosicao();
        }
            
        return false;
    }
 
    public boolean moveDown() {
        if(super.moveDown()){
            Facing=1;
            if(moving){
                switch (Down) {
                case 0:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer11.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Down++;
                    break;
                case 1:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer12.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Down++;
                    break;
                case 2:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer13.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Down++;
                    break;
                case 3:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer14.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Down=0;
                    break;
                default:
                    break;
                }
            }
            return validaPosicao();
        }
            
        return false;
    }

    public boolean moveRight() {
        if(super.moveRight()){
            Facing=2;
            if(moving){
                switch (Right) {
                case 0:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer31.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Right++;
                    break;
                case 1:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer32.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Right++;
                    break;
                case 2:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer33.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Right++;
                    break;
                case 3:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer34.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Right=0;
                    break;
                default:
                    break;
                }
            }
            return validaPosicao();
        }
        
        return false;
    }

    public boolean moveLeft() {
        if(super.moveLeft()){
            Facing=3;
            if(moving){
                switch (Left) {
                case 0:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer23.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Left++;
                    break;
                case 1:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer22.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Left++;
                    break;
                case 2:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer23.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Left++;
                    break;
                case 3:
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer24.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                    Left=0;
                    break;
                default:
                    break;
                }
            }
            return validaPosicao();
        }
        return false;
    }  
    
    
    public void Atirar() {

        switch (this.Facing) {
            case 0:
                {
                    Tiro f = new Tiro("tiro0.png",0);
                    f.setPosicao(pPosicao.getLinha(),pPosicao.getColuna());
                    Desenho.acessoATelaDoJogo().addPersonagem(f);
                    break;
                }
            case 1:
                {
                    Tiro f = new Tiro("tiro11.png",1);
                    f.setPosicao(pPosicao.getLinha(),pPosicao.getColuna());
                    Desenho.acessoATelaDoJogo().addPersonagem(f);
                    break;
                }
            case 2:
                {
                    Tiro f = new Tiro("tiro1.png",2);
                    f.setPosicao(pPosicao.getLinha(),pPosicao.getColuna());
                    Desenho.acessoATelaDoJogo().addPersonagem(f);
                    break;
                }
            case 3:
                {
                    Tiro f = new Tiro("tiro3.png",3);
                    f.setPosicao(pPosicao.getLinha(),pPosicao.getColuna());
                    Desenho.acessoATelaDoJogo().addPersonagem(f);
                    break;
                }
        }
    }
    
    
    private void importImg(){
      try {        
            img = ImageIO.read(new File("/poketrainers.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void loadAnimations() {
        animations = new BufferedImage[4][4];
        for(int j=0;j<animations.length;j++)
            for(int i=0;i< animations[j].length;i++){
                animations[j][i]=img.getSubimage(i*32,j*48,32,47);
            }
    }
    
    public void updateAnimationTick() {
        aniTick++;
        if(aniTick>=aniSpeed){
            aniTick=0;
            aniIndex++;
            if(aniIndex>=4){
                aniIndex=0;
            }
        }
        
    }
    public void render(Graphics g){
        if(moving){
            g.drawImage(animations[playerAction][aniIndex],this.pPosicao.getLinha(),this.pPosicao.getColuna(),50,50,null);
        }else{
            g.drawImage(animations[playerAction][2],this.pPosicao.getLinha(),this.pPosicao.getColuna(),50,50,null);
        }
    }
    
    
    
    
    private void setAnimation() {
        if(moving){
            switch(playerDir){
                case LEFT:
                    playerAction=RUNNINGLEFT;
                    break;
                case UP:
                    playerAction=RUNNINGUP;
                    break;
                case RIGHT:
                    playerAction=RUNNINGRIGHT;
                    break;
                case DOWN:
                    playerAction=RUNNINGDOWN;
                    break;
            }
        }else{
            
        }
    }
    
    
    
    private void updatePos() {
        moving=false;
        if(!this.getPosicao().igual(new Posicao(0,8))){
            if(left &&!right){
                moving=true;
                moveLeft();
            }else if(right &&!left){
                moving=true;
                moveRight();
            }
            if(up &&!down){
                moving=true;
                moveUp();
            }else if(down &&!up){
                moving=true;
                moveDown();
            }
            if(moving==false){
                if(Facing==3){
                   try {
                            this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer23.png");
                    } catch (IOException ex) {
                            Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    } 
                }else if(Facing==2){
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer33.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }else if(Facing==1){
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer13.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }else if(Facing==0){
                    try {
                        this.iImage = new ImageIcon(new java.io.File(".").getCanonicalPath() + Consts.PATH + "btrainer43.png");
                    } catch (IOException ex) {
                        Logger.getLogger(Hero.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }    
        }
        
    }
    
    
    
        public void resetDirBooleans() {
        left=false;
        up=false;
        down=false;
        right=false;
    }
    
    public boolean isLeft() {
        return left;
    }

    public boolean isUp() {
        return up;
    }

    public boolean isRight() {
        return right;
    }

    public boolean isDown() {
        return down;
    }

    public void setLeft(boolean left) {
        this.left = left;
    }

    public void setUp(boolean up) {
        this.up = up;
    }

    public void setRight(boolean right) {
        this.right = right;
    }

    public void setDown(boolean down) {
        this.down = down;
    }

    public void setPlayerDir(int playerDir) {
        this.playerDir = playerDir;
    }

    public void update() {
        updatePos();
        updateAnimationTick();
        setAnimation();
    }
    
}
