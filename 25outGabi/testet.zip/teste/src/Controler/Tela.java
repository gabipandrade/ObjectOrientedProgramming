package Controler;

import Auxiliar.Consts;
import Auxiliar.Desenho;
import Auxiliar.Posicao;
import Modelo.BichinhoVaiVemHorizontal;
import Modelo.Bichinhoteleporta;
import Modelo.Bloco;
import Modelo.Caveira;
import Modelo.Hero;
import Modelo.Muro;
import Modelo.Personagem;
import Modelo.ZigueZague;
import Modelo.pokeball;
import Modelo.snake;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
//import java.util.zip.GZIPInputStream;
//import java.util.zip.GZIPOutputStream;
//import javax.swing.JButton;

public final class Tela extends javax.swing.JFrame implements MouseListener, KeyListener {

    private final Hero hero;
    private final ArrayList<Personagem> faseAtual;
    private final ControleDeJogo cj;
    private Graphics g2;
    private int iTimer;
    private int Fase;
    public Tela() {
        this.cj = new ControleDeJogo();
        iTimer = 0;
        Fase=1;
        Desenho.setCenario(this);
        initComponents();
        this.addMouseListener(this);
        /*mouse*/
        this.addKeyListener(this);
        /*teclado*/

 /*Cria a janela do tamanho do tabuleiro + insets (bordas) da janela*/
        this.setSize(Consts.RESy * Consts.CELL_SIDE + getInsets().left + getInsets().right,
                Consts.RESx * Consts.CELL_SIDE + getInsets().top + getInsets().bottom);

        faseAtual = new ArrayList<Personagem>();
        
        
        /*Cria faseAtual adiciona personagens*/
        hero = new Hero("btrainer11.png");
        hero.setPosicao(14, 5);
        this.addPersonagem(hero);
//
//        ZigueZague zz = new ZigueZague("robo.png");
//        zz.setPosicao(5, 5);
//        this.addPersonagem(zz);
//
//        BichinhoVaiVemHorizontal bBichinhoH = new BichinhoVaiVemHorizontal("roboPink.png");
//        bBichinhoH.setPosicao(3, 3);
//        this.addPersonagem(bBichinhoH);
//
//        BichinhoVaiVemHorizontal bBichinhoH2 = new BichinhoVaiVemHorizontal("roboPink.png");
//        bBichinhoH2.setPosicao(6, 6);
//        this.addPersonagem(bBichinhoH2);
        /*
        Caveira bV1 = new Caveira("caveira.png");
        bV1.setPosicao(5, 1);
        this.addPersonagem(bV1);
        
        Caveira bV2 = new Caveira("caveira.png");
        bV2.setPosicao(6, 1);
        this.addPersonagem(bV2);
        
        Caveira bV3 = new Caveira("caveira.png");
        bV3.setPosicao(7, 1);
        this.addPersonagem(bV3);
         */
        pokeball pb1 = new pokeball("pokeball2.png");
        pb1.setPosicao(3, 2);
        this.addPersonagem(pb1);

        pokeball pb2 = new pokeball("pokeball2.png");
        pb2.setPosicao(10, 3);
        this.addPersonagem(pb2);

        pokeball pb3 = new pokeball("pokeball2.png");
        pb3.setPosicao(3, 12);
        this.addPersonagem(pb3);

        pokeball pb4 = new pokeball("pokeball.png");
        pb4.setPosicao(12, 12);
        this.addPersonagem(pb4);
        
         Bloco bloc = new Bloco ("bloco.png");
        bloc.setPosicao(1, 4);
        this.addPersonagem(bloc);
         
        Bloco bloc1 = new Bloco ("bloco.png");
        bloc1.setPosicao(8, 6);
        this.addPersonagem(bloc1);
         Bloco bloc2 = new Bloco ("bloco.png");
        bloc2.setPosicao(12, 9);
        this.addPersonagem(bloc2);
         Bloco bloc3 = new Bloco ("bloco.png");
        bloc3.setPosicao(12, 10);
        this.addPersonagem(bloc3);
        
        snake s1 = new snake("snake.png");
        s1.setPosicao(3, 7);
        this.addPersonagem(s1);

        snake s2 = new snake("snake.png");
        s2.setPosicao(5, 14);
        this.addPersonagem(s2);

        snake s3 = new snake("snake.png");
        s3.setPosicao(10, 6);
        this.addPersonagem(s3);

        Bichinhoteleporta bt = new Bichinhoteleporta("pokeball2.png");
        bt.setPosicao(2, 2);
        this.addPersonagem(bt);

        Muro[] muros2 = new Muro[60];

        Muro[] muros1 = new Muro[75];
        int a = 0;
        // Preencher o vetor com imagens "muro.png" nas posições especificadas
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                if ((i == 2 && j != 2 && j != 5 && j != 6 && j <= 12)
                        || (i == 4 && j >= 6 && j <= 12)
                        || (i == 9 && j >= 2 && j <= 8)
                        || (j == 13 && i >= 2 && i <= 5)
                        || (i == 11 && j >= 2 && j <= 7)
                        || (j == 11 && i >= 8 && i <= 13)
                        || (j == 13 && i >= 9 && i <= 13)
                        || (j == 9 && i >= 6 && i <= 10)
                        || (i == 1 && j == 7)
                        || (i == 3 && (j == 1 || j == 3))
                        || ((i == 4) && (j == 2))
                        || (i == 5 && j == 6)
                        || (i == 6 && (j == 6 || j == 8 || j == 9))
                        || (i == 7 && (j == 6 || j == 2 || j == 4 || j == 13 || j == 14))
                        || (i == 8 && (j == 2 || j == 4 || j == 10))
                        || (i == 10 && j == 2)
                        || (i == 13 && ((j >= 2 && j <= 4) || (j == 8) || (j == 12)))
                        || (i == 12 && j == 7)
                        || (i == 14 && (j == 2 || j == 9))) {
                    muros1[a] = new Muro("muro.png");
                    muros1[a].setPosicao(i, j);

                    this.addPersonagem(muros1[a]);
                    a++;
                }
            }

        }

        int b = 0;
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                if (j == 15 || j == 0 || i == 0 || i == 15) {
                    muros2[b] = new Muro("muro.png");
                    muros2[b].setPosicao(i, j);

                    this.addPersonagem(muros2[b]);
                    b++;
                }
            }
        }
        
    }
    public void Fase2(){
        hero.setPosicao(14,5);
        /*Cria faseAtual adiciona personagens*/
        Caveira bV1 = new Caveira("caveira.png");
        bV1.setPosicao(5, 1);
        faseAtual.add(bV1);
        
        Caveira bV2 = new Caveira("caveira.png");
        bV2.setPosicao(6, 1);
        this.addPersonagem(bV2);
        
        Caveira bV3 = new Caveira("caveira.png");
        bV3.setPosicao(7, 1);
        this.addPersonagem(bV3);
        
        Bichinhoteleporta bt = new Bichinhoteleporta("pokeball.png");
        bt.setPosicao(2, 2);
        this.addPersonagem(bt);
        pokeball pb1 = new pokeball("pokeball2.png");
        pb1.setPosicao(3, 2);
        this.addPersonagem(pb1);

        pokeball pb2 = new pokeball("pokeball2.png");
        pb2.setPosicao(10, 3);
        this.addPersonagem(pb2);

        pokeball pb3 = new pokeball("pokeball2.png");
        pb3.setPosicao(3, 12);
        this.addPersonagem(pb3);

        pokeball pb4 = new pokeball("pokeball2.png");
        pb4.setPosicao(12, 12);
        this.addPersonagem(pb4);

        Muro[] muros2 = new Muro[60];

        // Preencher o vetor com imagens "muro.png" nas posições especificada
        int b = 0;
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                if (j == 15 || j == 0 || i == 0 || i == 15) {
                    muros2[b] = new Muro("muro.png");
                    muros2[b].setPosicao(i, j);

                    this.addPersonagem(muros2[b]);
                    b++;
                }
            }
        }
            
    }
    public void Fase3(){
       hero.setPosicao(14,5);
        /*Cria faseAtual adiciona personagens*/
        
        Bichinhoteleporta bt = new Bichinhoteleporta("pokeball2.png");
        bt.setPosicao(2, 2);
        this.addPersonagem(bt);
        pokeball pb1 = new pokeball("pokeball2.png");
        pb1.setPosicao(4, 4);
        this.addPersonagem(pb1);

        pokeball pb2 = new pokeball("pokeball2.png");
        pb2.setPosicao(9, 9);
        this.addPersonagem(pb2);

        pokeball pb3 = new pokeball("pokeball2.png");
        pb3.setPosicao(2, 12);
        this.addPersonagem(pb3);

        pokeball pb4 = new pokeball("pokeball.png");
        pb4.setPosicao(1, 1);
        this.addPersonagem(pb4);

        Muro[] muros2 = new Muro[60];

        // Preencher o vetor com imagens "muro.png" nas posições especificada
        int b = 0;
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                if (j == 15 || j == 0 || i == 0 || i == 15) {
                    muros2[b] = new Muro("muro.png");
                    muros2[b].setPosicao(i, j);

                    this.addPersonagem(muros2[b]);
                    b++;
                }
            }
        }
        
    }
    public void Fase4(){
       hero.setPosicao(14,5);
        /*Cria faseAtual adiciona personagens*/
        Bichinhoteleporta bt = new Bichinhoteleporta("pokeball2.png");
        bt.setPosicao(2, 2);
        this.addPersonagem(bt);
        pokeball pb1 = new pokeball("pokeball2.png");
        pb1.setPosicao(3, 8);
        this.addPersonagem(pb1);

        pokeball pb2 = new pokeball("pokeball.png");
        pb2.setPosicao(4, 5);
        this.addPersonagem(pb2);

        pokeball pb3 = new pokeball("pokeball2.png");
        pb3.setPosicao(9, 1);
        this.addPersonagem(pb3);

        pokeball pb4 = new pokeball("pokeball.png");
        pb4.setPosicao(12, 12);
        this.addPersonagem(pb4);

        Muro[] muros2 = new Muro[60];

        // Preencher o vetor com imagens "muro.png" nas posições especificada
        int b = 0;
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                if (j == 15 || j == 0 || i == 0 || i == 15) {
                    muros2[b] = new Muro("muro.png");
                    muros2[b].setPosicao(i, j);

                    this.addPersonagem(muros2[b]);
                    b++;
                }
            }
        }
        
    }
    public void Fase5(){
       hero.setPosicao(14,5);
        /*Cria faseAtual adiciona personagens*/
        Bichinhoteleporta bt = new Bichinhoteleporta("pokeball2.png");
        bt.setPosicao(2, 2);
        this.addPersonagem(bt);
        
        Bichinhoteleporta bt1 = new Bichinhoteleporta("pokeball2.png");
        bt.setPosicao(5, 1);
        this.addPersonagem(bt1);
        
        Bichinhoteleporta bt2 = new Bichinhoteleporta("pokeball2.png");
        bt.setPosicao(1, 5);
        this.addPersonagem(bt2);
        
        
        Muro[] muros2 = new Muro[60];

        // Preencher o vetor com imagens "muro.png" nas posições especificada
        int b = 0;
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                if (j == 15 || j == 0 || i == 0 || i == 15) {
                    muros2[b] = new Muro("muro.png");
                    muros2[b].setPosicao(i, j);

                    this.addPersonagem(muros2[b]);
                    b++;
                }
            }
        }
        
    }
    public void GameOver(){
    
    }
    public int getFase() {
        return Fase;
    }

    public void setFase(int Fase) {
        this.Fase = Fase;
    }
    
    public boolean ehPosicaoValida(Posicao p) {
        return cj.ehPosicaoValida(this.faseAtual, p);
    }

    public void addPersonagem(Personagem umPersonagem) {
        faseAtual.add(umPersonagem);
    }

    public void removePersonagem(Personagem umPersonagem) {
        faseAtual.remove(umPersonagem);
    }

    public Graphics getGraphicsBuffer() {
        return g2;
    }

    public void paint(Graphics gOld) {
        Graphics g = this.getBufferStrategy().getDrawGraphics();
        /*Criamos um contexto gráfico*/
        g2 = g.create(getInsets().left, getInsets().top, getWidth() - getInsets().right, getHeight() - getInsets().top);
        /**
         * ***********Desenha cenário de fundo*************
         */
        for (int i = 0; i < Consts.RESx; i++) {
            for (int j = 0; j < Consts.RESy; j++) {
                try {
                    if (j >= 16) {
                        Image newImage = Toolkit.getDefaultToolkit().getImage(new java.io.File(".").getCanonicalPath() + Consts.PATH + "grass1.png");
                        g2.drawImage(newImage,
                                j * Consts.CELL_SIDE, i * Consts.CELL_SIDE, Consts.CELL_SIDE, Consts.CELL_SIDE, null);
                        
                    } else if(i==0 && j==8){
                        Image newImage = Toolkit.getDefaultToolkit().getImage(new java.io.File(".").getCanonicalPath() + Consts.PATH + "seta.png");
                        g2.drawImage(newImage,
                                j * Consts.CELL_SIDE, i * Consts.CELL_SIDE, Consts.CELL_SIDE, Consts.CELL_SIDE, null);
                        
                    }else {
                        Image newImage = Toolkit.getDefaultToolkit().getImage(new java.io.File(".").getCanonicalPath() + Consts.PATH + "grass1.png");
                        g2.drawImage(newImage,
                                j * Consts.CELL_SIDE, i * Consts.CELL_SIDE, Consts.CELL_SIDE, Consts.CELL_SIDE, null);

                    }

                } catch (IOException ex) {
                    Logger.getLogger(Tela.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

        if (!this.faseAtual.isEmpty()) {
            this.cj.desenhaTudo(faseAtual);
            this.cj.processaTudo(faseAtual);
        }

        g.dispose();
        g2.dispose();
        if (!getBufferStrategy().contentsLost()) {
            getBufferStrategy().show();
        }
        
        if(faseAtual.size()==1 && Fase==1){
            int delay=0;
            for(int i=0;i<50;i++){
                delay++;
                System.out.println("Delay Para iniciar fase "+ (Fase+1) +" = "+(50-delay));
            }
            hero.setPoints(0);
            Fase2();
            Fase++;
        }else if(faseAtual.size()==1 && Fase==2){
            int delay=0;
            for(int i=0;i<50;i++){
                delay++;
                System.out.println("Delay Para iniciar fase "+ (Fase+1) +" = "+(50-delay));
            }
            
            hero.setPoints(0);
            Fase3();
            Fase++;
        }else if(faseAtual.size()==1 && Fase==3){
            int delay=0;
            for(int i=0;i<50;i++){
                delay++;
                System.out.println("Delay Para iniciar fase "+ (Fase+1) +" = "+(50-delay));
            }
            
            hero.setPoints(0);
            Fase4();
            Fase++;
        }else if(faseAtual.size()==1 && Fase==4){
            int delay=0;
            for(int i=0;i<50;i++){
                delay++;
                System.out.println("Delay Para iniciar fase "+ (Fase+1) +" = "+(50-delay));
            }
            
            hero.setPoints(0);
            Fase5();
            Fase++;
        
        }else if(faseAtual.size()==1 && Fase==5){
         GameOver();
        }
        if(Fase<=4){
            this.setTitle("Fase "+Fase+ "\tPontos :"+ hero.getPoints());
        }else if(Fase==5){
            this.setTitle("Fase Bonus!\tPontos :"+ hero.getPoints());
        }else{
            this.setTitle("Game Over");
        }
    }

    public void go() {
        TimerTask task = new TimerTask() {
            public void run() {
                repaint();
            }
        };
        Timer timer = new Timer();
        timer.schedule(task, 0, Consts.PERIOD);
    }

    public void keyPressed(KeyEvent e) {
        if (iTimer%10==0) {
            iTimer = 0;
            
            if (e.getKeyCode() == KeyEvent.VK_C) {
                this.faseAtual.clear();
            }else if(e.getKeyCode() == KeyEvent.VK_SPACE){
                this.hero.Atirar();
            }else if (e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) {
                hero.moveUp();
            } else if (e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_S) {
                hero.moveDown();
            } else if (e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A) {
                hero.moveLeft();
            } else if (e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D) {
                hero.moveRight();
            }
            //this.setTitle("-> Cell: " + (hero.getPosicao().getColuna()) + ", "
            //      + (hero.getPosicao().getLinha()));
            //repaint(); /*invoca o paint imediatamente, sem aguardar o refresh*/
        } else {
            System.out.println("Timer="+iTimer);
            iTimer++;
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        /* Clique do mouse desligado*/
        int x = e.getX();
        int y = e.getY();

        this.setTitle("X: "+ x + ", Y: " + y +
        " -> Cell: " + (y/Consts.CELL_SIDE) + ", " + (x/Consts.CELL_SIDE));
        this.hero.getPosicao().setPosicao(y/Consts.CELL_SIDE, x/Consts.CELL_SIDE);
        
        repaint();
    }


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("POO2023-1 - Skooter");
        setAlwaysOnTop(true);
        setAutoRequestFocus(false);
        setResizable(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 561, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

    public void mouseMoved(MouseEvent e) {
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    public void mouseDragged(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }
}
