/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Auxiliar.Posicao;
import java.io.Serializable;

/**
 *
 * @author gabi
 */
public class Bloco extends Personagem implements Serializable{
    
    public Bloco(String sNomeImagePNG) {
        super(sNomeImagePNG);
        this.bmovivel =true;
        this.bMortal =false;
        this.bTransponivel=false;
    }

    public Posicao getpPosicao() {
        return pPosicao;
    }

    public void setpPosicao(Posicao pPosicao) {
        this.pPosicao = pPosicao;
    }

    public boolean isBmovivel() {
        return bmovivel;
    }

    public void setBmovivel(boolean bmovivel) {
        this.bmovivel = bmovivel;
    }
    
}
