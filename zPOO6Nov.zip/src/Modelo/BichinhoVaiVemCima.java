/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Auxiliar.Desenho;
import auxiliar.Posicao;
import java.io.Serializable;

/**
 *
 * @author rafael
 */
public class BichinhoVaiVemCima extends Personagem  implements Serializable{
    private boolean bRight;
    private int contaFrames;
    
    public BichinhoVaiVemCima(String sNomeImagePNG) {
        super(sNomeImagePNG);
        bRight = true;
        this.bMortal=true;
        this.bAtiravel=true;
    }
    private boolean validaPosicao(Posicao p){
        if (!Desenho.acessoATelaDoJogo().ehPosicaoValida(p)) {
            this.voltaAUltimaPosicao();
            return false;
        }
        return true;       
    }
    public void voltaAUltimaPosicao(){
        this.pPosicao.volta();
    }


    public void autoDesenho(){
        contaFrames++;
        if(bRight && contaFrames==1){
            if(validaPosicao(new Posicao(pPosicao.getLinha()+1,pPosicao.getColuna()))){
                this.setPosicao(pPosicao.getLinha()+1, pPosicao.getColuna());
                contaFrames=0; 
            }else{
                bRight=false;
                contaFrames=0;
            }
        }
        else if(!bRight && contaFrames==1){
            if(validaPosicao(new Posicao(pPosicao.getLinha()-1,pPosicao.getColuna()))){

                this.setPosicao(pPosicao.getLinha()-1, pPosicao.getColuna());           
                contaFrames=0;         
            }else{
                bRight=true;
                contaFrames=0;
            }
        }    
        super.autoDesenho();
    }
        
}
