package Modelo;

import java.io.Serializable;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author rafael
 */
public class snake extends Personagem implements Serializable{
    
    public snake(String sNomeImagePNG) {
        super(sNomeImagePNG);
        this.bTransponivel=false;
        this.bAtiravel=true;
    }
    
}
