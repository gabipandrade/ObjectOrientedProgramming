import Controler.Tela;
import javax.swing.JFrame;

public class Main {

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Tela tTela = new Tela();
                tTela.createBufferStrategy(3);
                tTela.setLocationRelativeTo(null);
                tTela.setVisible(true);
                tTela.go();
                //tTela.pack();
            }
        });
    }
}
/*
        jframe= new JFrame();
        jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jframe.add(gamePanel);
        jframe.setResizable(false);
        jframe.pack();
        jframe.setLocationRelativeTo(null);
        jframe.setVisible(true);
*/